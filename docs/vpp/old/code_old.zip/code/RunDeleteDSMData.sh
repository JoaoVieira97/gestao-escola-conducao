#! /bin/sh

./RunSample.sh ormsamples.DeleteDSMData  $@
