#! /bin/sh

./RunSample.sh ormsamples.ListDSMData  $@
