#! /bin/sh

./RunSample.sh ormsamples.CreateDSMData  $@
