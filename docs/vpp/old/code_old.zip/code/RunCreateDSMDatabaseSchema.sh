#! /bin/sh

./RunSample.sh ormsamples.CreateDSMDatabaseSchema  $@
