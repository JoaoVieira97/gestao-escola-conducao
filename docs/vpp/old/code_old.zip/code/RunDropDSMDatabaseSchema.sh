#! /bin/sh

./RunSample.sh ormsamples.DropDSMDatabaseSchema  $@
