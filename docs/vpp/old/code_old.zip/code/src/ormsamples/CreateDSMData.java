/**
 * Licensee: Hugo Oliveira(Universidade do Minho)
 * License Type: Academic
 */
package ormsamples;

import org.orm.*;
public class CreateDSMData {
	public void createTestData() throws PersistentException {
		PersistentTransaction t = dsm.DSMPersistentManager.instance().getSession().beginTransaction();
		try {
			dsm.WorkingDay ldsmWorkingDay = dsm.WorkingDayDAO.createWorkingDay();
			// Initialize the properties of the persistent object here
			dsm.WorkingDayDAO.save(ldsmWorkingDay);
			dsm.Instructor ldsmInstructor = dsm.InstructorDAO.createInstructor();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : theoreticalLessons, workingDays, practicalLessons
			dsm.InstructorDAO.save(ldsmInstructor);
			dsm.Secretary ldsmSecretary = dsm.SecretaryDAO.createSecretary();
			// Initialize the properties of the persistent object here
			dsm.SecretaryDAO.save(ldsmSecretary);
			dsm.Student ldsmStudent = dsm.StudentDAO.createStudent();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : theoreticalLessons, practicalLessons, payments, exams, registers, announcements, nif
			dsm.StudentDAO.save(ldsmStudent);
			dsm.SchoolInfo ldsmSchoolInfo = dsm.SchoolInfoDAO.createSchoolInfo();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : endTime, startTime, maxTimeToCancel
			dsm.SchoolInfoDAO.save(ldsmSchoolInfo);
			dsm.Announcement ldsmAnnouncement = dsm.AnnouncementDAO.createAnnouncement();
			// Initialize the properties of the persistent object here
			dsm.AnnouncementDAO.save(ldsmAnnouncement);
			dsm.PersonalAnnouncement ldsmPersonalAnnouncement = dsm.PersonalAnnouncementDAO.createPersonalAnnouncement();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : viewed
			dsm.PersonalAnnouncementDAO.save(ldsmPersonalAnnouncement);
			dsm.Register ldsmRegister = dsm.RegisterDAO.createRegister();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : instructor, license
			dsm.RegisterDAO.save(ldsmRegister);
			dsm.LicenseCar ldsmLicenseCar = dsm.LicenseCarDAO.createLicenseCar();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : theoreticalLessons, practicalLessons
			dsm.LicenseCarDAO.save(ldsmLicenseCar);
			dsm.Exam ldsmExam = dsm.ExamDAO.createExam();
			// Initialize the properties of the persistent object here
			dsm.ExamDAO.save(ldsmExam);
			dsm.Payment ldsmPayment = dsm.PaymentDAO.createPayment();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : secretary, licenseCar
			dsm.PaymentDAO.save(ldsmPayment);
			dsm.TheoreticalLesson ldsmTheoreticalLesson = dsm.TheoreticalLessonDAO.createTheoreticalLesson();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : themes, students, instructor
			dsm.TheoreticalLessonDAO.save(ldsmTheoreticalLesson);
			dsm.PracticalLesson ldsmPracticalLesson = dsm.PracticalLessonDAO.createPracticalLesson();
			// TODO Initialize the properties of the persistent object here, the following properties must be initialized before saving : students, isStudentPresent, instructor
			dsm.PracticalLessonDAO.save(ldsmPracticalLesson);
			dsm.Theme ldsmTheme = dsm.ThemeDAO.createTheme();
			// Initialize the properties of the persistent object here
			dsm.ThemeDAO.save(ldsmTheme);
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
		
	}
	
	public static void main(String[] args) {
		try {
			CreateDSMData createDSMData = new CreateDSMData();
			try {
				createDSMData.createTestData();
			}
			finally {
				dsm.DSMPersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
