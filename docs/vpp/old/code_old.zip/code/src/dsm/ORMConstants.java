/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Hugo Oliveira(Universidade do Minho)
 * License Type: Academic
 */
package dsm;

public interface ORMConstants extends org.orm.util.ORMBaseConstants {
	final int KEY_INSTRUCTOR_PRACTICALLESSONS = -1466908248;
	
	final int KEY_INSTRUCTOR_THEORETICALLESSONS = 1597655253;
	
	final int KEY_INSTRUCTOR_WORKINGDAYS = 1716430502;
	
	final int KEY_PAYMENT_LICENSECAR = -525594676;
	
	final int KEY_PAYMENT_SECRETARY = -1403876705;
	
	final int KEY_PRACTICALLESSON_INSTRUCTOR = 1066420367;
	
	final int KEY_PRACTICALLESSON_STUDENTS = 271208970;
	
	final int KEY_REGISTER_INSTRUCTOR = 942836633;
	
	final int KEY_REGISTER_LICENSE = 1386564293;
	
	final int KEY_STUDENT_ANNOUNCEMENTS = 1021639912;
	
	final int KEY_STUDENT_EXAMS = 203917584;
	
	final int KEY_STUDENT_PAYMENTS = 1270109393;
	
	final int KEY_STUDENT_PRACTICALLESSONS = 1898265610;
	
	final int KEY_STUDENT_REGISTERS = 883430668;
	
	final int KEY_STUDENT_THEORETICALLESSONS = 1419358903;
	
	final int KEY_THEORETICALLESSON_INSTRUCTOR = 2010520572;
	
	final int KEY_THEORETICALLESSON_STUDENTS = 884481207;
	
	final int KEY_THEORETICALLESSON_THEMES = 844813993;
	
}
