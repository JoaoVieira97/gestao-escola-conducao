#! /bin/sh

./RunSample.sh ormsamples.RetrieveAndUpdateDSMData  $@
